import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class AppleAffiliatesPage extends StatefulWidget {
  const AppleAffiliatesPage({super.key});

  @override
  State<AppleAffiliatesPage> createState() => _AppleAffiliatesPageState();
}

class _AppleAffiliatesPageState extends State<AppleAffiliatesPage> {
  static const String _functionsRegion = 'europe-west1';
  final _functions = FirebaseFunctions.instanceFor(region: _functionsRegion);
  final _money = NumberFormat.currency(locale: 'ar', symbol: 'ر.س', decimalDigits: 2);
  final _num = NumberFormat.decimalPattern('ar');

  bool _loading = true;
  bool _busy = false;
  String? _error;

  Map<String, dynamic> _data = <String, dynamic>{};
  String _selectedInfluencer = '';
  DateTimeRange? _range;

  List<Map<String, dynamic>> get _influencers => _asList(_data['influencers']);
  List<Map<String, dynamic>> get _codes => _asList(_data['codes']);
  List<Map<String, dynamic>> get _transactions => _asList(_data['transactions']);
  Map<String, dynamic> get _summary => _asMap(_data['summary']);

  @override
  void initState() {
    super.initState();
    _load();
  }

  static List<Map<String, dynamic>> _asList(dynamic value) {
    if (value is List) {
      return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    }
    return <Map<String, dynamic>>[];
  }

  static Map<String, dynamic> _asMap(dynamic value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    return <String, dynamic>{};
  }

  double _toDouble(dynamic v) {
    if (v is num) return v.toDouble();
    return double.tryParse('$v'.replaceAll(',', '.')) ?? 0;
  }

  int _toInt(dynamic v) {
    if (v is num) return v.round();
    return int.tryParse('$v') ?? 0;
  }

  String _s(dynamic v, [String fallback = '']) => (v ?? fallback).toString().trim();

  String _influencerName(String id) {
    if (id.isEmpty) return 'غير محدد';
    for (final i in _influencers) {
      if (_s(i['id']) == id) return _s(i['name'], 'غير محدد');
    }
    return id;
  }

  String _date(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  bool get _useCallableRestFallback => Platform.isWindows || Platform.isLinux;

  String _friendlyError(Object e) {
    final raw = e.toString();
    if (raw.contains('CloudFunctionsHostApi.call') || raw.contains('Unable to establish connection on channel')) {
      return 'نسخة سطح المكتب لا تستطيع الاتصال بإضافة Cloud Functions مباشرة. تم تجهيز اتصال احتياطي عبر HTTPS، أعد المحاولة بعد استبدال الملف وتشغيل التطبيق من جديد.';
    }
    if (raw.contains('unauthenticated') || raw.contains('سجّل دخولك')) {
      return 'سجّل دخولك بحساب الأونر أو الأدمن ثم أعد المحاولة.';
    }
    return raw;
  }

  Future<Map<String, dynamic>> _callFunction(String name, Map<String, dynamic> data) async {
    if (!_useCallableRestFallback) {
      final result = await _functions.httpsCallable(name).call(data);
      final value = result.data;
      if (value is Map) return Map<String, dynamic>.from(value);
      return <String, dynamic>{'value': value};
    }
    return _callFunctionRest(name, data);
  }

  Future<Map<String, dynamic>> _callFunctionRest(String name, Map<String, dynamic> data) async {
    final projectId = Firebase.app().options.projectId;
    if (projectId.isEmpty) {
      throw Exception('لم يتم العثور على Firebase projectId. تأكد من تهيئة Firebase قبل فتح اللوحة.');
    }

    final user = FirebaseAuth.instance.currentUser;
    final idToken = await user?.getIdToken();
    if (idToken == null || idToken.isEmpty) {
      throw Exception('سجّل دخولك بحساب الأونر أو الأدمن ثم أعد المحاولة.');
    }

    final uri = Uri.parse('https://$_functionsRegion-$projectId.cloudfunctions.net/$name');
    final client = HttpClient();
    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $idToken');
      req.write(jsonEncode(<String, dynamic>{'data': data}));

      final res = await req.close();
      final body = await utf8.decodeStream(res);
      dynamic decoded;
      try {
        decoded = body.isEmpty ? <String, dynamic>{} : jsonDecode(body);
      } catch (_) {
        decoded = <String, dynamic>{'raw': body};
      }

      if (res.statusCode < 200 || res.statusCode >= 300 || (decoded is Map && decoded['error'] != null)) {
        final err = decoded is Map ? decoded['error'] : null;
        final message = err is Map
            ? (err['message'] ?? err['status'] ?? body).toString()
            : body;
        throw Exception(message.isEmpty ? 'تعذر الاتصال بدوال Firebase.' : message);
      }

      final result = decoded is Map ? (decoded['result'] ?? decoded['data'] ?? decoded) : decoded;
      if (result is Map) return Map<String, dynamic>.from(result);
      return <String, dynamic>{'value': result};
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final map = await _callFunction('appleAffiliateDashboard', <String, dynamic>{
        if (_selectedInfluencer.isNotEmpty) 'influencerId': _selectedInfluencer,
        if (_range != null) 'from': _date(_range!.start),
        if (_range != null) 'to': _date(_range!.end),
      });
      if (mounted) setState(() => _data = map);
    } on FirebaseFunctionsException catch (e) {
      if (mounted) setState(() => _error = e.message ?? e.code);
    } catch (e) {
      if (mounted) setState(() => _error = _friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _runBusy(Future<void> Function() action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await action();
      await _load();
    } on FirebaseFunctionsException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? e.code)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickRange() async {
    final now = DateTime.now();
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 3),
      lastDate: DateTime(now.year + 1),
      initialDateRange: _range ?? DateTimeRange(start: now.subtract(const Duration(days: 30)), end: now),
      helpText: 'اختر فترة التقرير',
      saveText: 'تطبيق',
      cancelText: 'إلغاء',
    );
    if (r == null) return;
    setState(() => _range = r);
    await _load();
  }

  Future<void> _addInfluencerDialog() async {
    final name = TextEditingController();
    final handle = TextEditingController();
    final email = TextEditingController();
    final phone = TextEditingController();
    final percent = TextEditingController(text: '10');
    final fixed = TextEditingController(text: '0');
    String type = 'percent';

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة مؤثر'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _field(name, 'اسم المؤثر', icon: Icons.person_outline),
                _field(handle, 'حسابه / المعرف', icon: Icons.alternate_email),
                _field(email, 'البريد', icon: Icons.email_outlined),
                _field(phone, 'الجوال', icon: Icons.phone_outlined),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: type,
                  decoration: const InputDecoration(labelText: 'نوع العمولة', border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(value: 'percent', child: Text('نسبة من صافي Apple')),
                    DropdownMenuItem(value: 'fixed', child: Text('مبلغ ثابت لكل عملية')),
                    DropdownMenuItem(value: 'hybrid', child: Text('مبلغ ثابت + نسبة')),
                  ],
                  onChanged: (v) => setDialogState(() => type = v ?? 'percent'),
                ),
                const SizedBox(height: 10),
                _field(percent, 'النسبة %', keyboardType: TextInputType.number, icon: Icons.percent),
                _field(fixed, 'مبلغ ثابت بالريال', keyboardType: TextInputType.number, icon: Icons.payments_outlined),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    await _runBusy(() async {
      await _callFunction('createAppleAffiliateInfluencer', <String, dynamic>{
        'name': name.text.trim(),
        'handle': handle.text.trim(),
        'email': email.text.trim(),
        'phone': phone.text.trim(),
        'commissionType': type,
        'commissionPercent': _toDouble(percent.text),
        'commissionFixedSar': _toDouble(fixed.text),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إضافة المؤثر')));
    });
  }

  Future<void> _createCodeDialog() async {
    final code = TextEditingController();
    final campaign = TextEditingController();
    final appleOfferId = TextEditingController();
    final discountLabel = TextEditingController(text: 'خصم خاص من Apple');
    final discountValue = TextEditingController(text: '50');
    final limit = TextEditingController(text: '25000');
    final productId = TextEditingController(text: 'vip_monthly1');
    DateTime? expiry;
    String influencerId = _influencers.isNotEmpty ? _s(_influencers.first['id']) : '';
    String discountType = 'percent';

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إنشاء كود Apple رسمي'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'لازم يكون عندك Apple Offer ID جاهز في App Store Connect. الخصم الفعلي يحدده عرض Apple، واللوحة تحفظه للتقارير.',
                  style: Theme.of(ctx).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                _field(code, 'الكود مثال WAZEN50', ltr: true, icon: Icons.confirmation_number_outlined),
                _field(campaign, 'اسم الحملة', icon: Icons.campaign_outlined),
                DropdownButtonFormField<String>(
                  value: influencerId.isEmpty ? null : influencerId,
                  decoration: const InputDecoration(labelText: 'المؤثر', border: OutlineInputBorder()),
                  items: _influencers
                      .map((i) => DropdownMenuItem(value: _s(i['id']), child: Text(_s(i['name']))))
                      .toList(),
                  onChanged: (v) => setDialogState(() => influencerId = v ?? ''),
                ),
                const SizedBox(height: 10),
                _field(appleOfferId, 'Apple Offer Code ID', ltr: true, icon: Icons.apple),
                _field(productId, 'Product ID', ltr: true, icon: Icons.inventory_2_outlined),
                _field(discountLabel, 'وصف الخصم للمستخدم/التقرير', icon: Icons.label_outline),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: discountType,
                        decoration: const InputDecoration(labelText: 'نوع الخصم', border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'percent', child: Text('نسبة')),
                          DropdownMenuItem(value: 'fixed', child: Text('مبلغ')),
                          DropdownMenuItem(value: 'final_price', child: Text('سعر نهائي')),
                        ],
                        onChanged: (v) => setDialogState(() => discountType = v ?? 'percent'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: _field(discountValue, 'القيمة', keyboardType: TextInputType.number)),
                  ],
                ),
                _field(limit, 'حد الاستخدام', keyboardType: TextInputType.number, icon: Icons.numbers_outlined),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final picked = await showDatePicker(
                      context: ctx,
                      firstDate: now,
                      lastDate: DateTime(now.year + 2),
                      initialDate: now.add(const Duration(days: 90)),
                    );
                    if (picked != null) setDialogState(() => expiry = picked);
                  },
                  icon: const Icon(Icons.date_range_outlined),
                  label: Text(expiry == null ? 'اختيار تاريخ نهاية' : 'ينتهي: ${_date(expiry!)}'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إنشاء')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    await _runBusy(() async {
      final data = await _callFunction('createAppleAffiliateOfferCode', <String, dynamic>{
        'code': code.text.trim(),
        'campaignName': campaign.text.trim(),
        'influencerId': influencerId,
        'appleOfferCodeId': appleOfferId.text.trim(),
        'productId': productId.text.trim(),
        'discountLabel': discountLabel.text.trim(),
        'discountType': discountType,
        'discountValue': _toDouble(discountValue.text),
        'numberOfCodes': _toInt(limit.text),
        if (expiry != null) 'expirationDate': _date(expiry!),
      });
      final url = _s(data['redemptionUrl']);
      if (!mounted) return;
      if (url.isNotEmpty) {
        await Clipboard.setData(ClipboardData(text: url));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء الكود ونسخ رابط الاسترداد')));
      }
    });
  }

  Future<void> _addTransactionDialog([Map<String, dynamic>? codeRow]) async {
    String code = _s(codeRow?['code']);
    final gross = TextEditingController(text: '18');
    final proceeds = TextEditingController(text: '12');
    final percent = TextEditingController(text: '10');
    final fixed = TextEditingController(text: '0');
    final tx = TextEditingController();
    DateTime purchaseDate = DateTime.now();
    String commissionType = 'percent';

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة عملية للتقرير'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: code.isEmpty ? null : code,
                  decoration: const InputDecoration(labelText: 'الكود', border: OutlineInputBorder()),
                  items: _codes
                      .map((c) => DropdownMenuItem(value: _s(c['code']), child: Text(_s(c['code']))))
                      .toList(),
                  onChanged: (v) => setDialogState(() => code = v ?? ''),
                ),
                const SizedBox(height: 10),
                _field(gross, 'المبلغ الإجمالي قبل Apple', keyboardType: TextInputType.number),
                _field(proceeds, 'صافي Apple Proceeds', keyboardType: TextInputType.number),
                DropdownButtonFormField<String>(
                  value: commissionType,
                  decoration: const InputDecoration(labelText: 'نوع العمولة', border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(value: 'percent', child: Text('نسبة')),
                    DropdownMenuItem(value: 'fixed', child: Text('مبلغ ثابت')),
                    DropdownMenuItem(value: 'hybrid', child: Text('مبلغ + نسبة')),
                  ],
                  onChanged: (v) => setDialogState(() => commissionType = v ?? 'percent'),
                ),
                const SizedBox(height: 10),
                _field(percent, 'النسبة %', keyboardType: TextInputType.number),
                _field(fixed, 'مبلغ ثابت', keyboardType: TextInputType.number),
                _field(tx, 'Transaction ID اختياري', ltr: true),
                OutlinedButton.icon(
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      firstDate: DateTime(DateTime.now().year - 2),
                      lastDate: DateTime(DateTime.now().year + 1),
                      initialDate: purchaseDate,
                    );
                    if (d != null) setDialogState(() => purchaseDate = d);
                  },
                  icon: const Icon(Icons.date_range),
                  label: Text('تاريخ العملية: ${_date(purchaseDate)}'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    await _runBusy(() async {
      await _callFunction('addAppleAffiliateTransaction', <String, dynamic>{
        'code': code,
        'grossSar': _toDouble(gross.text),
        'appleProceedsSar': _toDouble(proceeds.text),
        'commissionType': commissionType,
        'commissionPercent': _toDouble(percent.text),
        'commissionFixedSar': _toDouble(fixed.text),
        'transactionId': tx.text.trim(),
        'purchaseDate': _date(purchaseDate),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت إضافة العملية')));
    });
  }

  Future<void> _toggleCode(Map<String, dynamic> row, bool active) async {
    final code = _s(row['code']);
    final confirm = active
        ? true
        : await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('إيقاف الكود؟'),
              content: const Text('إيقاف كود Apple قد لا يمكن التراجع عنه في App Store Connect. هل تريد المتابعة؟'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إيقاف')),
              ],
            ),
          );
    if (confirm != true) return;
    await _runBusy(() async {
      await _callFunction('updateAppleAffiliateOfferCode', <String, dynamic>{
        'code': code,
        'active': active,
      });
    });
  }

  Future<void> _exportPdf() async {
    final font = pw.Font.ttf(await rootBundle.load('assets/Tajawal-Regular.ttf'));
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: font, bold: font));
    final influencerLabel = _selectedInfluencer.isEmpty ? 'كل المؤثرين' : _influencerName(_selectedInfluencer);
    final period = _range == null ? 'كل الفترات' : '${_date(_range!.start)} إلى ${_date(_range!.end)}';

    pw.Widget kv(String k, String v) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 3),
          child: pw.Row(children: [
            pw.Expanded(child: pw.Text(k, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
            pw.Text(v),
          ]),
        );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        build: (ctx) => [
          pw.Text('أرباح وازن', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold, color: PdfColors.teal800)),
          pw.SizedBox(height: 6),
          pw.Text('تقرير أكواد Apple والمؤثرين', style: const pw.TextStyle(fontSize: 13)),
          pw.SizedBox(height: 16),
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(color: PdfColors.grey100, borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Column(children: [
              kv('المؤثر', influencerLabel),
              kv('الفترة', period),
              kv('عدد الاشتراكات', _num.format(_toInt(_summary['subscribers']))),
              kv('إجمالي المبيعات', _money.format(_toDouble(_summary['grossSar']))),
              kv('صافي Apple', _money.format(_toDouble(_summary['appleProceedsSar']))),
              kv('عمولة المؤثرين', _money.format(_toDouble(_summary['commissionSar']))),
              kv('صافي وازن بعد العمولة', _money.format(_toDouble(_summary['netSar']))),
            ]),
          ),
          pw.SizedBox(height: 18),
          pw.Text('تفاصيل العمليات', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          if (_transactions.isEmpty)
            pw.Text('لا توجد عمليات في هذه الفترة.')
          else
            pw.Table.fromTextArray(
              headers: ['التاريخ', 'الكود', 'المؤثر', 'صافي Apple', 'عمولة المؤثر', 'صافي وازن'],
              data: _transactions.map((tx) {
                final inf = _influencerName(_s(tx['influencerId']));
                return [
                  _s(tx['purchaseDate'], _s(tx['createdAt'], '—')),
                  _s(tx['code']),
                  inf,
                  _money.format(_toDouble(tx['appleProceedsSar'])),
                  _money.format(_toDouble(tx['commissionSar'])),
                  _money.format(_toDouble(tx['netSar'])),
                ];
              }).toList(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.teal700),
              cellAlignment: pw.Alignment.centerRight,
              border: pw.TableBorder.all(color: PdfColors.grey300),
            ),
          pw.SizedBox(height: 18),
          pw.Container(
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(color: PdfColors.teal50, borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Text(
              'ملاحظة الصرف: يتم احتساب أرباح المؤثرين بناءً على صافي Apple Proceeds المسجل في وازن. موعد صرف أرباح الشراكات يكون بعد ظهور مستحقات Apple النهائية في App Store Connect وتحويلها للحساب البنكي حسب تقويم Apple المالي.',
              style: const pw.TextStyle(fontSize: 11),
            ),
          ),
        ],
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final name = 'wazen_affiliate_report_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.pdf';
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(await doc.save(), flush: true);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم إنشاء التقرير: $name')));
    await OpenFile.open(file.path);
  }

  Widget _field(
    TextEditingController ctrl,
    String label, {
    TextInputType? keyboardType,
    IconData? icon,
    bool ltr = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        textDirection: ltr ? ui.TextDirection.ltr : ui.TextDirection.rtl,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: icon == null ? null : Icon(icon),
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final width = MediaQuery.of(context).size.width;
    final isWide = width > 720;

    return Scaffold(
      appBar: AppBar(
        title: const Text('شراكات Apple وأكواد الخصم'),
        actions: [
          IconButton(onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh), tooltip: 'تحديث'),
          IconButton(onPressed: _loading ? null : _exportPdf, icon: const Icon(Icons.picture_as_pdf_outlined), tooltip: 'تصدير PDF'),
        ],
      ),
      floatingActionButton: _busy
          ? const FloatingActionButton(onPressed: null, child: CircularProgressIndicator())
          : FloatingActionButton.extended(
              onPressed: _createCodeDialog,
              icon: const Icon(Icons.add),
              label: const Text('كود جديد'),
            ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _ErrorState(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      _HeaderCard(
                        rangeText: _range == null ? 'كل الفترات' : '${_date(_range!.start)} → ${_date(_range!.end)}',
                        influencerText: _selectedInfluencer.isEmpty ? 'كل المؤثرين' : _influencerName(_selectedInfluencer),
                        onPickRange: _pickRange,
                        onClearRange: _range == null
                            ? null
                            : () async {
                                setState(() => _range = null);
                                await _load();
                              },
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          SizedBox(
                            width: isWide ? (width - 52) / 4 : double.infinity,
                            child: _MetricCard(title: 'المشتركين', value: _num.format(_toInt(_summary['subscribers'])), icon: Icons.people_alt_outlined),
                          ),
                          SizedBox(
                            width: isWide ? (width - 52) / 4 : double.infinity,
                            child: _MetricCard(title: 'صافي Apple', value: _money.format(_toDouble(_summary['appleProceedsSar'])), icon: Icons.apple),
                          ),
                          SizedBox(
                            width: isWide ? (width - 52) / 4 : double.infinity,
                            child: _MetricCard(title: 'عمولة المؤثرين', value: _money.format(_toDouble(_summary['commissionSar'])), icon: Icons.handshake_outlined),
                          ),
                          SizedBox(
                            width: isWide ? (width - 52) / 4 : double.infinity,
                            child: _MetricCard(title: 'صافي وازن', value: _money.format(_toDouble(_summary['netSar'])), icon: Icons.account_balance_wallet_outlined),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text('المؤثرون', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
                                  ),
                                  TextButton.icon(onPressed: _addInfluencerDialog, icon: const Icon(Icons.person_add_alt), label: const Text('إضافة مؤثر')),
                                ],
                              ),
                              const SizedBox(height: 8),
                              DropdownButtonFormField<String>(
                                value: _selectedInfluencer.isEmpty ? '' : _selectedInfluencer,
                                decoration: const InputDecoration(labelText: 'فلترة حسب المؤثر', border: OutlineInputBorder()),
                                items: [
                                  const DropdownMenuItem(value: '', child: Text('كل المؤثرين')),
                                  ..._influencers.map((i) => DropdownMenuItem(value: _s(i['id']), child: Text(_s(i['name'])))),
                                ],
                                onChanged: (v) async {
                                  setState(() => _selectedInfluencer = v ?? '');
                                  await _load();
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      _SectionTitle(title: 'أكواد Apple الرسمية', action: TextButton.icon(onPressed: _createCodeDialog, icon: const Icon(Icons.add), label: const Text('إنشاء كود'))),
                      if (_codes.isEmpty)
                        const _EmptyCard(text: 'لا توجد أكواد حتى الآن')
                      else
                        ..._codes.map((c) => _CodeCard(
                              row: c,
                              influencerName: _influencerName(_s(c['influencerId'])),
                              onCopy: () async {
                                final url = _s(c['redemptionUrl']);
                                await Clipboard.setData(ClipboardData(text: url));
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ رابط Apple')));
                              },
                              onAddTx: () => _addTransactionDialog(c),
                              onToggle: (v) => _toggleCode(c, v),
                            )),
                      const SizedBox(height: 14),
                      _SectionTitle(title: 'آخر العمليات', action: TextButton.icon(onPressed: () => _addTransactionDialog(), icon: const Icon(Icons.add_card), label: const Text('إضافة عملية'))),
                      if (_transactions.isEmpty)
                        const _EmptyCard(text: 'لا توجد عمليات في الفترة المحددة')
                      else
                        Card(
                          child: ListView.separated(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _transactions.length,
                            separatorBuilder: (_, __) => Divider(height: 1, color: cs.outlineVariant),
                            itemBuilder: (context, index) {
                              final tx = _transactions[index];
                              return ListTile(
                                leading: CircleAvatar(child: Text(_s(tx['code']).isEmpty ? 'A' : _s(tx['code']).substring(0, 1))),
                                title: Text('${_s(tx['code'])} • ${_influencerName(_s(tx['influencerId']))}'),
                                subtitle: Text('صافي Apple: ${_money.format(_toDouble(tx['appleProceedsSar']))} • العمولة: ${_money.format(_toDouble(tx['commissionSar']))}'),
                                trailing: Text(_money.format(_toDouble(tx['netSar'])), style: const TextStyle(fontWeight: FontWeight.w900)),
                              );
                            },
                          ),
                        ),
                      const SizedBox(height: 90),
                    ],
                  ),
                ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final String rangeText;
  final String influencerText;
  final VoidCallback onPickRange;
  final VoidCallback? onClearRange;

  const _HeaderCard({
    required this.rangeText,
    required this.influencerText,
    required this.onPickRange,
    required this.onClearRange,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [cs.primaryContainer.withOpacity(.75), cs.surface]),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: cs.outlineVariant.withOpacity(.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('لوحة شراكات وازن', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('إنشاء أكواد Apple Custom Codes، ربطها بالمؤثرين، متابعة الأرباح والعمولات، وتصدير تقرير PDF.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.45)),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              Chip(label: Text('الفترة: $rangeText')),
              Chip(label: Text('المؤثر: $influencerText')),
              ActionChip(avatar: const Icon(Icons.date_range, size: 18), label: const Text('تغيير الفترة'), onPressed: onPickRange),
              if (onClearRange != null) ActionChip(label: const Text('إزالة الفترة'), onPressed: onClearRange),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MetricCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: cs.primaryContainer, child: Icon(icon, color: cs.onPrimaryContainer)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
                const SizedBox(height: 4),
                FittedBox(alignment: Alignment.centerRight, fit: BoxFit.scaleDown, child: Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final Widget? action;
  const _SectionTitle({required this.title, this.action});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
        if (action != null) action!,
      ],
    );
  }
}

class _CodeCard extends StatelessWidget {
  final Map<String, dynamic> row;
  final String influencerName;
  final VoidCallback onCopy;
  final VoidCallback onAddTx;
  final ValueChanged<bool> onToggle;

  const _CodeCard({
    required this.row,
    required this.influencerName,
    required this.onCopy,
    required this.onAddTx,
    required this.onToggle,
  });

  String _s(dynamic v, [String fallback = '']) => (v ?? fallback).toString().trim();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final active = row['active'] == true;
    final code = _s(row['code']);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: cs.primary.withOpacity(.10),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: cs.primary.withOpacity(.25)),
                  ),
                  child: Directionality(
                    textDirection: ui.TextDirection.ltr,
                    child: Text(code, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(_s(row['campaignName'], 'حملة بدون اسم'), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900))),
                Switch.adaptive(value: active, onChanged: onToggle),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(label: Text(active ? 'مفعل' : 'موقوف')),
                Chip(label: Text('المؤثر: $influencerName')),
                Chip(label: Text(_s(row['discountLabel'], 'عرض Apple'))),
                if (_s(row['expirationDate']).isNotEmpty) Chip(label: Text('النهاية: ${_s(row['expirationDate'])}')),
                Chip(label: Text('الحد: ${_s(row['numberOfCodes'], '—')}')),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(onPressed: onCopy, icon: const Icon(Icons.copy), label: const Text('نسخ رابط Apple')),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(onPressed: onAddTx, icon: const Icon(Icons.add_card), label: const Text('إضافة عملية')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final String text;
  const _EmptyCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Center(child: Text(text)),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}

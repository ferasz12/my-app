// lib/screens/guide_page.dart
import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';


import '../shared/premium_feature.dart';
import '../shared/premium_gate.dart';

// صفحات داخلية
import 'restaurants_page.dart';
import 'virtual_gym_page.dart';
import 'training_schedule_page.dart';
import '../features/recipes/ui/recipes_explore_page.dart';
import 'community_page.dart';

// شارات/حساب
import '../community/local_repos.dart'; // LocalAuthRepo().currentUser()
import '../community/models.dart'; // AppUser
import '../models/badge.dart'; // enum BadgeType
import '../shared/user_badges_store.dart'; // مصدر الشارات

// ✅ صفحات المالك والدعم داخل features
import '../features/admin/owner_page.dart'; // OwnerPage
import '../features/support/support_page.dart'; // SupportPage

// أخرى (عدّل اسم الباكيج لو مو my_app)
import '../gyms/gyms_map_page.dart';

// خدمة الأدوار
import '../core/auth/roles_service.dart';

/// الغلاف: يسمح بالدخول لأي مستخدم مسجّل (غير المسجّل فقط يُمنع).
class GuidePage extends StatelessWidget {
  const GuidePage({super.key});

  @override
  Widget build(BuildContext context) {
    // ✅ لا نستخدم StreamBuilder هنا حتى لا تبقى صفحة دليلك فارغة بانتظار auth stream.
    // currentUser متوفر فورًا بعد AuthGate، وأي تغيّر تسجيل دخول تتعامل معه AuthGate.
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const _NotAllowed(reason: "الرجاء تسجيل الدخول للوصول إلى هذه الصفحة");
    }
    return PremiumGate(
      feature: PremiumFeature.guide,
      child: const GuidePageInner(),
    );
  }
}


class _GuideSilentShell extends StatelessWidget {
  const _GuideSilentShell();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(backgroundColor: cs.surface, body: const SizedBox.expand());
  }
}

class _NotAllowed extends StatelessWidget {
  final String reason;
  const _NotAllowed({required this.reason});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("دليلك"),
      ),
      body: Stack(
        children: [
          _GuideBackground(colorScheme: cs),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: _GlassPanel(
                  child: Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock_outline_rounded, size: 64, color: cs.primary),
                        const SizedBox(height: 14),
                        Text(
                          reason,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(height: 1.25),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GuidePageInner extends StatefulWidget {
  const GuidePageInner({super.key});

  @override
  State<GuidePageInner> createState() => _GuidePageState();
}

class _GuidePageState extends State<GuidePageInner> {
  // ✅ أداء سريع: دليلك يفتح فورًا، ثم يقرأ الدور/الشارة بالخلفية بدون تعليق.
  static const bool _enableOpeningRoleAndBadgeFetch = true;
  final RolesService _roles = RolesService();
  final UserBadgesStore _badges = UserBadgesStore(); // غيّرها لو عندك Singleton مختلف
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  AppUser? _me;
  BadgeType? _myBadge;

  bool _isOwner = false;
  bool _isAdmin = false;
  bool _isSupport = false;
  // ✅ نعرض دليلك فورًا. الأدوار والشارات تتحدث بالخلفية وتظهر لو المستخدم مالك/دعم.
  bool _loading = false;

  StreamSubscription<AppRole>? _roleSub;
  bool _routeOpening = false;

  Future<void> _safePush(Widget page) async {
    if (_routeOpening || !mounted) return;
    _routeOpening = true;
    try {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => page),
      );
    } finally {
      // نترك مهلة بسيطة حتى لا يضغط المستخدم مرتين ويفتح نفس الصفحة مرتين.
      await Future<void>.delayed(const Duration(milliseconds: 180));
      _routeOpening = false;
    }
  }

  @override
  void initState() {
    super.initState();
    _resolveEverything();
  }

  @override
  void dispose() {
    _roleSub?.cancel();
    super.dispose();
  }

  Future<void> _resolveEverything() async {
    // ✅ دليلك يفتح فورًا من FirebaseAuth والكاش المحلي.
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return;

    if (mounted) {
      setState(() {
        _me = AppUser(
          uid: u.uid,
          email: u.email ?? '',
          displayName: (u.displayName ?? '').trim(),
          photoUrl: u.photoURL,
        );
        _loading = false;
      });
    }

    // 1) أظهر لوحات المالك/الدعم فورًا لو كان عندنا كاش سابق.
    await _loadGuideAccessFromCache(u.uid);

    // 2) لا نعلّق الصفحة؛ نحدّث الدور والشارة من السحابة بالخلفية فقط.
    if (_enableOpeningRoleAndBadgeFetch) {
      unawaited(_refreshGuideAccessInBackground(u.uid));
    }
  }

  Future<void> _loadGuideAccessFromCache(String uid) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final roleRaw = prefs.getString('guide_role_$uid');
      final badgeRaw = prefs.getString('guide_badge_$uid');
      final badge = badgeRaw == null ? null : badgeFromString(badgeRaw);

      if (!mounted) return;
      setState(() {
        if (roleRaw != null) _applyRole(_roleFromString(roleRaw));
        if (badge != null && badge != BadgeType.none) _myBadge = badge;
      });
    } catch (e) {
      debugPrint('[GuidePage] cache role/badge skipped: $e');
    }
  }

  Future<void> _refreshGuideAccessInBackground(String uid) async {
    try {
      // الدور أولًا حتى تظهر لوحة المالك/الدعم بأسرع وقت، خصوصًا للحسابات المصرّح لها.
      final role = await _roles.currentUserRoleOnce().timeout(const Duration(seconds: 2));
      if (mounted) setState(() => _applyRole(role));

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('guide_role_$uid', _roleToString(role));
    } catch (e) {
      debugPrint('[GuidePage] background role fetch skipped: $e');
    }

    try {
      final badge = await _badges.getBadge(uid).timeout(const Duration(seconds: 2));
      if (mounted) setState(() => _myBadge = badge);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('guide_badge_$uid', badge.name);
    } catch (e) {
      debugPrint('[GuidePage] background badge fetch skipped: $e');
    }

    // تحديث اختياري لاسم/صورة المستخدم من Firestore، بدون أن يؤثر على فتح الصفحة.
    try {
      final me = await LocalAuthRepo().currentUser().timeout(const Duration(seconds: 2));
      if (mounted) setState(() => _me = me);
    } catch (e) {
      debugPrint('[GuidePage] background user fetch skipped: $e');
    }
  }

  void _applyRole(AppRole role) {
    _isOwner = role == AppRole.owner;
    _isAdmin = role == AppRole.admin;
    _isSupport = role == AppRole.support || _isAdmin || _isOwner;
  }

  AppRole _roleFromString(String value) {
    switch (value.toLowerCase()) {
      case 'owner':
        return AppRole.owner;
      case 'admin':
        return AppRole.admin;
      case 'support':
        return AppRole.support;
      default:
        return AppRole.user;
    }
  }

  String _roleToString(AppRole role) {
    switch (role) {
      case AppRole.owner:
        return 'owner';
      case AppRole.admin:
        return 'admin';
      case AppRole.support:
        return 'support';
      case AppRole.user:
        return 'user';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final tt = theme.textTheme;

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // منطق الإظهار حسب الرتبة (لا تغيّر)
    final showSupportPanel = _isOwner || _isSupport || _myBadge == BadgeType.support;
    final showOwnerPanel = _isOwner;

    final items = <_GuideCard>[
      _GuideCard(
        icon: Icons.restaurant,
        title: 'استكشف الوصفات',
        description: 'تصفّح وصفات المجتمع مع الماكروز والسعرات.',
        onTap: () => _safePush(RecipesExplorePage()),
      ),
      _GuideCard(
        icon: Icons.forum_rounded,
        title: 'مجتمع وازن',
        description: 'بوستات نصية، أسئلة، معلومات، وصفات وتعليقات من المستخدمين.',
        onTap: () => _safePush(const CommunityPage()),
      ),
      _GuideCard(
        icon: Icons.fastfood_rounded,
        title: 'المطاعم',
        description: 'دليل الأكل الجاهز والاختيارات المناسبة لأهدافك.',
        onTap: () => _safePush(RestaurantsPage()),
      ),
      _GuideCard(
        icon: Icons.fitness_center,
        title: 'الصالة الافتراضية',
        description: 'تمارين وفيديوهات بإرشادات بسيطة.',
        onTap: () => _safePush(VirtualGymPage()),
      ),
      _GuideCard(
        icon: Icons.schedule_rounded,
        title: 'جداول التدريب',
        description: 'أنشئ جدولك أو اختر من جداول جاهزة.',
        onTap: () => _safePush(TrainingSchedulePage()),
      ),
      _GuideCard(
        icon: Icons.map_outlined,
        title: 'النوادي القريبة',
        description: 'استكشف نوادي قريبة منك على الخريطة.',
        onTap: () => _safePush(GymsMapPage()),
      ),

      // 👇 تظهر حسب الصلاحيات
      if (showSupportPanel)
        _GuideCard(
          icon: Icons.support_agent,
          title: 'الدعم الفني',
          description: 'مراقبة التطبيق، إدارة المستخدمين والبلاغات.',
          onTap: () => _safePush(SupportPage()),
        ),


      if (showOwnerPanel)
        _GuideCard(
          icon: Icons.workspace_premium_rounded,
          title: 'لوحة المالك',
          description: 'تعديل الرتب، تبنيد، إيقاف وصفات، نقاط وإشعارات.',
          onTap: () => _safePush(OwnerPage()),
        ),

    ];

    final badgeLabel = (_myBadge == null) ? '' : _badgeLabel(_myBadge!);
    final uid = FirebaseAuth.instance.currentUser?.uid;

    // Grid responsive (UI فقط)
    final w = MediaQuery.of(context).size.width;
    final crossAxisCount = w >= 980 ? 3 : (w >= 640 ? 2 : 1);
    final childAspectRatio = crossAxisCount == 1 ? 2.95 : 1.65;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        titleSpacing: 16,
        title: const Text("دليلك"),
        actions: [
          if (badgeLabel.isNotEmpty)
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 12),
              child: _BadgePill(text: badgeLabel),
            ),
        ],
      ),
      body: Stack(
        children: [
          _GuideBackground(colorScheme: cs),
          SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
                    child: _GlassPanel(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                        child: Row(
                          children: [
                            _AvatarMark(colorScheme: cs),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // ✅ بدون Stream من Firestore: الاسم من FirebaseAuth/الكاش فقط.
                                  Text(
                                    _displayName(_me).isEmpty ? 'مرحبًا' : 'مرحبًا، ${_displayName(_me)}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'اختر وجهتك  — وصفات، مطاعم، تمارين، ونوادي قريبة.',
                                    style: tt.bodyMedium?.copyWith(
                                      color: tt.bodyMedium?.color?.withOpacity(.78),
                                      height: 1.25,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: crossAxisCount,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: childAspectRatio,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => _GuideCardWidget(
                        card: items[index],
                        cs: cs,
                        tt: tt,
                      ),
                      childCount: items.length,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// تسمية مرنة لأي قيمة من enum BadgeType عندك
  String _badgeLabel(BadgeType badge) {
    final raw = badge.toString();
    final name = raw.contains('.') ? raw.split('.').last : raw;
    final lowered = name.toLowerCase();
    if (lowered.isEmpty || lowered == 'none') return '';
    return name[0].toUpperCase() + name.substring(1);
  }

  String _displayName(AppUser? me) {
    if (me == null) return '';

    // AppUser في مشروعك يحتوي على: displayName / username / email
    // نخلي العرض آمن 100% بدون استخدام dynamic (عشان ما يصير NoSuchMethodError).
    final String fromName = me.displayName.trim();
    if (fromName.isNotEmpty) return fromName;

    final String username = me.username.trim();
    if (username.isNotEmpty) return username;

    final String email = me.email.trim();
    if (email.isNotEmpty && email.contains('@')) {
      return email.split('@').first;
    }
    return '';
  }
}

/// موديل البطاقة (لا تغيّر)
class _GuideCard {
  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;

  _GuideCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
  });
}

/// واجهة البطاقة (UI فقط)
class _GuideCardWidget extends StatelessWidget {
  final _GuideCard card;
  final ColorScheme cs;
  final TextTheme tt;

  const _GuideCardWidget({
    required this.card,
    required this.cs,
    required this.tt,
  });

  @override
  Widget build(BuildContext context) {
    // دخول أنيق بدون أي باكج إضافي
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) {
        return Opacity(
          opacity: v,
          child: Transform.translate(
            offset: Offset(0, (1 - v) * 10),
            child: child,
          ),
        );
      },
      child: _GlassCard(
        onTap: card.onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              _IconBadge(icon: card.icon, colorScheme: cs),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      card.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      card.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: tt.bodyMedium?.copyWith(
                        color: tt.bodyMedium?.color?.withOpacity(.76),
                        height: 1.22,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.arrow_forward_ios_rounded, size: 16, color: cs.onSurface.withOpacity(.55)),
            ],
          ),
        ),
      ),
    );
  }
}

/// خلفية فخمة وخفيفة (بدون منطق)
class _GuideBackground extends StatelessWidget {
  final ColorScheme colorScheme;
  const _GuideBackground({required this.colorScheme});

  @override
  Widget build(BuildContext context) {
    final cs = colorScheme;
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              cs.primary.withOpacity(.18),
              cs.surface,
              cs.secondary.withOpacity(.12),
            ],
          ),
        ),
        child: Stack(
          children: [
            // دوائر ضوء ناعمة
            Positioned(
              top: -80,
              right: -60,
              child: _GlowBlob(color: cs.primary.withOpacity(.22), size: 220),
            ),
            Positioned(
              bottom: -90,
              left: -70,
              child: _GlowBlob(color: cs.secondary.withOpacity(.18), size: 240),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowBlob extends StatelessWidget {
  final Color color;
  final double size;
  const _GlowBlob({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class _GlassPanel extends StatelessWidget {
  final Widget child;
  const _GlassPanel({required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: cs.surface.withOpacity(.70),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: cs.onSurface.withOpacity(.08)),
            boxShadow: [
              BoxShadow(
                color: cs.shadow.withOpacity(.10),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  const _GlassCard({required this.child, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return _GlassPanel(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: cs.primary.withOpacity(.08),
          highlightColor: cs.primary.withOpacity(.04),
          child: child,
        ),
      ),
    );
  }
}

class _IconBadge extends StatelessWidget {
  final IconData icon;
  final ColorScheme colorScheme;
  const _IconBadge({required this.icon, required this.colorScheme});

  @override
  Widget build(BuildContext context) {
    final cs = colorScheme;
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cs.primary.withOpacity(.18),
            cs.secondary.withOpacity(.14),
          ],
        ),
        border: Border.all(color: cs.onSurface.withOpacity(.08)),
      ),
      child: Icon(icon, size: 28, color: cs.primary),
    );
  }
}

class _AvatarMark extends StatelessWidget {
  final ColorScheme colorScheme;
  const _AvatarMark({required this.colorScheme});

  @override
  Widget build(BuildContext context) {
    final cs = colorScheme;
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [
            cs.primary.withOpacity(.22),
            cs.secondary.withOpacity(.18),
          ],
        ),
        border: Border.all(color: cs.onSurface.withOpacity(.10)),
      ),
      child: Icon(Icons.favorite_rounded, color: cs.primary, size: 22),
    );
  }
}

class _BadgePill extends StatelessWidget {
  final String text;
  const _BadgePill({required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return _GlassPanel(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.verified_rounded, size: 16, color: cs.primary),
            const SizedBox(width: 8),
            Text(
              text,
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

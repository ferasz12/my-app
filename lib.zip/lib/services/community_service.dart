import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/community_models.dart';

class CommunityService {
  CommunityService._();
  static final CommunityService instance = CommunityService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  CollectionReference<Map<String, dynamic>> get _posts => _db.collection('communityPosts');
  CollectionReference<Map<String, dynamic>> get _reports => _db.collection('communityReports');

  String? get currentUid => _auth.currentUser?.uid;

  Future<CommunityAuthorProfile> loadCurrentProfile() async {
    final user = _auth.currentUser;
    if (user == null) {
      throw FirebaseAuthException(code: 'not-signed-in', message: 'يجب تسجيل الدخول');
    }

    final snap = await _db.doc('users/${user.uid}').get();
    final data = snap.data() ?? const <String, dynamic>{};

    final role = (data['role'] ?? 'user').toString().toLowerCase().trim();
    final showAsSupport = role == 'owner' || role == 'admin' || role == 'support';

    final rawName = _firstNotEmpty([
      data['displayName'],
      data['name'],
      data['username'],
      user.displayName,
      user.email?.split('@').first,
    ]);

    final photo = _firstNotEmpty([
      data['photoUrl'],
      data['photoURL'],
      data['profileImageUrl'],
      user.photoURL,
    ]);

    return CommunityAuthorProfile(
      uid: user.uid,
      displayName: showAsSupport ? 'دعم وازن' : (rawName.isEmpty ? 'مستخدم وازن' : rawName),
      photoUrl: showAsSupport ? '' : photo,
      role: role.isEmpty ? 'user' : role,
      showAsSupport: showAsSupport,
    );
  }

  Future<String> createPost({
    required CommunityCategory category,
    required String content,
    String? recipeId,
    String? recipeTitle,
  }) async {
    final trimmed = content.trim();
    if (trimmed.length < 3) {
      throw ArgumentError('اكتب محتوى أوضح قبل النشر');
    }
    if (trimmed.length > 1800) {
      throw ArgumentError('النص طويل جدًا. اختصره إلى 1800 حرف كحد أقصى.');
    }

    final profile = await loadCurrentProfile();
    await _assertAllowedToPost(profile.uid);

    final ref = _posts.doc();
    await ref.set({
      'authorUid': profile.uid,
      'authorName': profile.displayName,
      'authorPhotoUrl': profile.photoUrl,
      'authorRole': profile.role,
      'supportDisplay': profile.showAsSupport,
      'category': category.firestoreValue,
      'content': trimmed,
      'likesCount': 0,
      'commentsCount': 0,
      'trendScore': 0,
      'isDeleted': false,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      if ((recipeId ?? '').trim().isNotEmpty) 'recipeId': recipeId!.trim(),
      if ((recipeTitle ?? '').trim().isNotEmpty) 'recipeTitle': recipeTitle!.trim(),
    });
    return ref.id;
  }

  Stream<List<CommunityPost>> streamPosts({required CommunitySort sort}) {
    return _posts
        .orderBy(sort.orderField, descending: true)
        .limit(160)
        .snapshots()
        .map((snap) {
      final list = snap.docs
          .map(CommunityPost.fromDoc)
          .where((p) => !p.isDeleted && p.content.trim().isNotEmpty)
          .toList(growable: false);
      if (sort == CommunitySort.latest) return list;
      return list;
    });
  }

  Stream<bool> streamIsLiked(String postId, String uid) {
    return _posts.doc(postId).collection('likes').doc(uid).snapshots().map((s) => s.exists);
  }

  Future<void> toggleLike(CommunityPost post) async {
    final uid = currentUid;
    if (uid == null) throw FirebaseAuthException(code: 'not-signed-in', message: 'يجب تسجيل الدخول');

    final likeRef = _posts.doc(post.id).collection('likes').doc(uid);
    final mirrorRef = _db.doc('users/$uid/communityLikes/${post.id}');
    final likeSnap = await likeRef.get();

    final batch = _db.batch();
    if (likeSnap.exists) {
      batch.delete(likeRef);
      batch.delete(mirrorRef);
      batch.update(_posts.doc(post.id), {
        'likesCount': FieldValue.increment(-1),
        'trendScore': FieldValue.increment(-2),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } else {
      batch.set(likeRef, {
        'uid': uid,
        'postId': post.id,
        'authorUid': post.authorUid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      batch.set(mirrorRef, {
        'postId': post.id,
        'authorUid': post.authorUid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      batch.update(_posts.doc(post.id), {
        'likesCount': FieldValue.increment(1),
        'trendScore': FieldValue.increment(2),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  }

  Future<void> addComment({required CommunityPost post, required String text}) async {
    final trimmed = text.trim();
    if (trimmed.length < 2) throw ArgumentError('اكتب تعليقًا أوضح');
    if (trimmed.length > 700) throw ArgumentError('التعليق طويل جدًا');

    final profile = await loadCurrentProfile();
    await _assertAllowedToPost(profile.uid);

    final postRef = _posts.doc(post.id);
    final commentRef = postRef.collection('comments').doc();
    final batch = _db.batch();
    batch.set(commentRef, {
      'authorUid': profile.uid,
      'authorName': profile.displayName,
      'authorPhotoUrl': profile.photoUrl,
      'authorRole': profile.role,
      'supportDisplay': profile.showAsSupport,
      'text': trimmed,
      'isDeleted': false,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    batch.update(postRef, {
      'commentsCount': FieldValue.increment(1),
      'trendScore': FieldValue.increment(3),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    await batch.commit();
  }

  Stream<List<CommunityComment>> streamComments(String postId, {int limit = 3}) {
    Query<Map<String, dynamic>> q = _posts
        .doc(postId)
        .collection('comments')
        .orderBy('createdAt', descending: false);
    if (limit > 0) q = q.limit(limit);
    return q.snapshots().map((snap) => snap.docs
        .map((d) => CommunityComment.fromDoc(postId: postId, doc: d))
        .where((c) => !c.isDeleted && c.text.trim().isNotEmpty)
        .toList(growable: false));
  }

  Stream<List<String>> streamMyLikedPostIds(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('communityLikes')
        .orderBy('createdAt', descending: true)
        .limit(120)
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.id).toList(growable: false));
  }

  Future<List<CommunityPost>> getPostsByIds(List<String> ids) async {
    if (ids.isEmpty) return const <CommunityPost>[];
    final futures = ids.take(80).map((id) => _posts.doc(id).get());
    final snaps = await Future.wait(futures);
    return snaps
        .where((s) => s.exists)
        .map(CommunityPost.fromDoc)
        .where((p) => !p.isDeleted && p.content.trim().isNotEmpty)
        .toList(growable: false);
  }


  Future<void> reportPost({
    required CommunityPost post,
    required String reason,
    String? details,
  }) async {
    final profile = await loadCurrentProfile();
    if (profile.uid == post.authorUid) {
      throw StateError('لا يمكنك الإبلاغ عن منشورك');
    }

    final cleanReason = reason.trim().isEmpty ? 'other' : reason.trim();
    final cleanDetails = (details ?? '').trim();
    if (cleanDetails.length > 700) {
      throw ArgumentError('تفاصيل البلاغ طويلة جدًا');
    }

    final reportRef = _reports.doc('${post.id}_${profile.uid}');
    await _db.runTransaction((tx) async {
      final reportSnap = await tx.get(reportRef);
      tx.set(reportRef, {
        'type': 'community_post',
        'status': 'open',
        'reason': cleanReason,
        'details': cleanDetails,
        'postId': post.id,
        'postAuthorUid': post.authorUid,
        'postAuthorName': post.authorName,
        'postAuthorPhotoUrl': post.authorPhotoUrl,
        'postCategory': post.category.firestoreValue,
        'postContent': post.content,
        'postCreatedAt': Timestamp.fromDate(post.createdAt),
        'reporterUid': profile.uid,
        'reporterName': profile.displayName,
        'reporterPhotoUrl': profile.photoUrl,
        'reporterRole': profile.role,
        'source': 'community_page',
        if (!reportSnap.exists) 'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (!reportSnap.exists) {
        tx.set(_posts.doc(post.id), {
          'reportsCount': FieldValue.increment(1),
          'lastReportedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    });
  }

  Future<void> deletePost(CommunityPost post) async {
    final profile = await loadCurrentProfile();
    final canDelete = profile.uid == post.authorUid || profile.showAsSupport;
    if (!canDelete) throw StateError('لا تملك صلاحية حذف هذا المنشور');
    await _posts.doc(post.id).set({
      'isDeleted': true,
      'deletedAt': FieldValue.serverTimestamp(),
      'deletedBy': profile.uid,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> _assertAllowedToPost(String uid) async {
    final snap = await _db.doc('users/$uid').get();
    final data = snap.data() ?? const <String, dynamic>{};
    if (data['isBanned'] == true) {
      throw StateError('حسابك محظور من النشر في وازن');
    }

    final communityTs = data['communitySuspendedUntil'];
    if (communityTs is Timestamp && DateTime.now().isBefore(communityTs.toDate())) {
      throw StateError('النشر في مجتمع وازن معلّق مؤقتًا لحسابك');
    }

    final recipesTs = data['recipesSuspendedUntil'];
    if (recipesTs is Timestamp && DateTime.now().isBefore(recipesTs.toDate())) {
      throw StateError('النشر معلّق مؤقتًا لحسابك');
    }
  }

  String _firstNotEmpty(List<dynamic> values) {
    for (final v in values) {
      final s = (v ?? '').toString().trim();
      if (s.isNotEmpty) return s;
    }
    return '';
  }
}
